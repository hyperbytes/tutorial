// JavaScript Document mymodule.js
exports.mycode1 = async function (options) {
    return "OK"
}
